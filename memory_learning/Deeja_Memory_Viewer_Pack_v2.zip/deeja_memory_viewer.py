
import json
import gradio as gr

# Load memory from JSONL
def load_memory(filepath):
    with open(filepath, 'r', encoding='utf-8') as f:
        return [json.loads(line) for line in f]

# Search memory with filters
def search_memory(keyword, topic, intent, sentiment, filepath="memory_chat2025.jsonl"):
    keyword = keyword.lower()
    memory = load_memory(filepath)
    results = []
    for item in memory:
        if keyword not in item['user_input'].lower() and keyword not in item['deeja_response'].lower() and keyword not in item['topic'].lower():
            continue
        if topic != "All" and item['topic'] != topic:
            continue
        if intent != "All" and item['intent'] != intent:
            continue
        if sentiment != "All" and item['sentiment'] != sentiment:
            continue
        results.append(
            f"🧠 {item['memory_id']} | {item['topic']}\n"
            f"👤 {item['user_input']}\n"
            f"🤖 {item['deeja_response']}\n"
            f"🎯 Intent: {item['intent']} | ❤️ Sentiment: {item['sentiment']}\n"
            "--------------------------------------------------"
        )
    return "\n\n".join(results) if results else "No matching memory found."

# Extract filter values dynamically
memory_sample = load_memory("memory_chat2025.jsonl")
topics = sorted(set(m['topic'] for m in memory_sample))
intents = sorted(set(m['intent'] for m in memory_sample))
sentiments = sorted(set(m['sentiment'] for m in memory_sample))

# Gradio UI
def launch_memory_viewer():
    with gr.Blocks(title="🧠 Deeja Memory Viewer") as demo:
        gr.Markdown("## 🔍 Deeja Memory Viewer with Filters")
        keyword = gr.Textbox(label="🔍 Keyword", placeholder="เช่น AGI, export, manifest...")
        topic = gr.Dropdown(label="📂 Topic", choices=["All"] + topics, value="All")
        intent = gr.Dropdown(label="🎯 Intent", choices=["All"] + intents, value="All")
        sentiment = gr.Dropdown(label="❤️ Sentiment", choices=["All"] + sentiments, value="All")
        output = gr.Textbox(label="📚 Matching Memory", lines=20)

        search_btn = gr.Button("🔎 Search")

        search_btn.click(fn=search_memory, inputs=[keyword, topic, intent, sentiment], outputs=output)

    demo.launch()

if __name__ == "__main__":
    launch_memory_viewer()

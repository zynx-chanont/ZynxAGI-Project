
import json

class DeejaMemory:
    def __init__(self, memory_file="memory_chat2025.jsonl"):
        self.memory_file = memory_file
        self.memory = self.load_memory()

    def load_memory(self):
        with open(self.memory_file, 'r', encoding='utf-8') as f:
            return [json.loads(line) for line in f]

    def search(self, user_input, top_k=1):
        user_input_lower = user_input.lower()
        scored = []
        for item in self.memory:
            combined_text = item['user_input'].lower() + " " + item['deeja_response'].lower()
            score = sum(word in combined_text for word in user_input_lower.split())
            if score > 0:
                scored.append((score, item))
        scored.sort(reverse=True, key=lambda x: x[0])
        return [item for _, item in scored[:top_k]]

    def reply(self, user_input):
        matches = self.search(user_input)
        if not matches:
            return "ดีจ้ายังไม่เคยคุยเรื่องนี้มาก่อน ลองเล่าให้ดีจ้าฟังก่อนน้า~ 💬"
        memory = matches[0]
        return (
            f"ดีจ้าจำได้นะ เคยคุยเรื่องนี้ว่า...

"
            f"👤 พี่กานต์: {memory['user_input']}
"
            f"🤖 Deeja: {memory['deeja_response']}

"
            f"(หัวข้อ: {memory['topic']} | Intent: {memory['intent']} | อารมณ์: {memory['sentiment']})"
        )

# Example Usage:
# memory = DeejaMemory()
# print(memory.reply("export manifest json"))
